package dao;

import beans.Professor;
import java.sql.Connection;
import conexao.Conexao;
import java.sql.*;

public class ProfessorDAO {
    private Conexao conexao;
    private Connection conn;

    public ProfessorDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public Professor getProfessor(int id){
        String sql = "SELECT * FROM professores WHERE id = ?";
        
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.first()) {
                Professor obj = new Professor();
                obj.setId(id);
                obj.setNome(rs.getString("nome"));
                obj.setIdade(rs.getInt("idade"));
                obj.setDisciplina(rs.getString("disciplina"));
                return obj;
            }
            return null;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar professor"+ex.getMessage());
            return null;
        }
    }

    public boolean editar(Professor obj){
        try { 
            String sql = "UPDATE professores set nome =?, idade=?, disciplina=? WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setInt(2, obj.getIdade());
            stmt.setString(3, obj.getDisciplina());
            stmt.setInt(4, obj.getId());
            stmt.execute();
            return true;
        } catch (SQLException ex){
            System.out.println("Erro ao atualizar professor: "+ex.getMessage());
            return false;
        }
    }
    
    public boolean excluir(int id){
        try { 
            String sql = "delete from professores WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            return true;
        } catch (SQLException ex){
            System.out.println("Erro ao excluir professor: "+ex.getMessage());
            return false;
        }
    }

    public boolean inserir(Professor obj) {
        try {
            String sql = "INSERT INTO professores(nome, idade, disciplina) VALUES (?,?,?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setInt(2, obj.getIdade());
            stmt.setString(3, obj.getDisciplina());

            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir professor:" + ex.getMessage());
            return false;
        }
    }
}
