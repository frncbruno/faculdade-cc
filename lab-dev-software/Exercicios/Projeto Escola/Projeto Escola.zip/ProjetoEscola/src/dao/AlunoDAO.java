package dao;

import beans.Aluno;
import java.sql.Connection;
import conexao.Conexao;
import java.sql.*;

public class AlunoDAO {
    private Conexao conexao;
    private Connection conn;

    public AlunoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public Aluno getAluno(int id){
        String sql = "SELECT * FROM alunos WHERE id = ?";
        
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.first()) {
                Aluno obj = new Aluno();
                obj.setId(id);
                obj.setNome(rs.getString("nome"));
                obj.setIdade(rs.getInt("idade"));
                obj.setCurso(rs.getString("curso"));
                return obj;
            }
            return null;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar aluno"+ex.getMessage());
            return null;
        }
    }

    public boolean editar(Aluno obj){
        try { 
            String sql = "UPDATE alunos set nome =?, idade=?, curso=? WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setInt(2, obj.getIdade());
            stmt.setString(3, obj.getCurso());
            stmt.setInt(4, obj.getId());
            stmt.execute();
            return true;
        } catch (SQLException ex){
            System.out.println("Erro ao atualizar aluno: "+ex.getMessage());
            return false;
        }
    }
    
    public boolean excluir(int id){
        try { 
            String sql = "delete from alunos WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            return true;
        } catch (SQLException ex){
            System.out.println("Erro ao excluir aluno: "+ex.getMessage());
            return false;
        }
    }

    public boolean inserir(Aluno obj) {
        try {
            String sql = "INSERT INTO alunos(nome, idade, curso) VALUES (?,?,?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, obj.getNome());
            stmt.setInt(2, obj.getIdade());
            stmt.setString(3, obj.getCurso());

            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir aluno:" + ex.getMessage());
            return false;
        }
    }
}
