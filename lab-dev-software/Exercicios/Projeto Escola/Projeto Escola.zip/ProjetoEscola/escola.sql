CREATE DATABASE IF NOT EXISTS escola;
USE escola;

CREATE TABLE IF NOT EXISTS alunos(
id int auto_increment PRIMARY KEY,
nome VARCHAR(50) NOT NULL,
idade int NOT NULL,
curso VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS professores(
id int auto_increment PRIMARY KEY,
nome VARCHAR(50) NOT NULL,
idade int NOT NULL,
disciplina VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS matriculas(
id int auto_increment PRIMARY KEY,
id_aluno INT,
id_professor INT,
data_matricula DATE,
FOREIGN KEY (id_aluno) references alunos(id),
FOREIGN KEY (id_professor) references professores(id)
);
