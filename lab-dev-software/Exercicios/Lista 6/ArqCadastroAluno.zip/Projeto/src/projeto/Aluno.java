/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package projeto;

public class Aluno {

    private String nome;
    private String dataNascimento;
    private String sexo;
    private int matricula;
    private String curso;
    private String cpf;
    private String rua;
    private String numero;
    private String bairro;
    private String cidade;
    private String cep;
    private String estado;
    private String telefone;

    public Aluno(String nome, String dataNascimento, String sexo,
                 int matricula, String curso, String cpf,
                 String rua, String numero, String bairro,
                 String cidade, String cep, String estado,
                 String telefone) {

        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
        this.matricula = matricula;
        this.curso = curso;
        this.cpf = cpf;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.cep = cep;
        this.estado = estado;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public String getSexo() {
        return sexo;
    }

    public int getMatricula() {
        return matricula;
    }

    public String getCurso() {
        return curso;
    }

    public String getCpf() {
        return cpf;
    }

    public String getRua() {
        return rua;
    }

    public String getNumero() {
        return numero;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public String getCep() {
        return cep;
    }

    public String getEstado() {
        return estado;
    }

    public String getTelefone() {
        return telefone;
    }

    // Converte o aluno para uma linha do arquivo TXT
    @Override
    public String toString() {
        return nome + ";" +
               dataNascimento + ";" +
               sexo + ";" +
               matricula + ";" +
               curso + ";" +
               cpf + ";" +
               rua + ";" +
               numero + ";" +
               bairro + ";" +
               cidade + ";" +
               cep + ";" +
               estado + ";" +
               telefone;
    }

    // Reconstrói um objeto Aluno a partir de uma linha do TXT
    public static Aluno fromString(String linha) {

        String[] dados = linha.split(";", -1);

        if (dados.length != 13) {
            throw new IllegalArgumentException("Linha inválida no arquivo.");
        }

        return new Aluno(
            dados[0],
            dados[1],
            dados[2],
            Integer.parseInt(dados[3]),
            dados[4],
            dados[5],
            dados[6],
            dados[7],
            dados[8],
            dados[9],
            dados[10],
            dados[11],
            dados[12]
        );
    }
}


