package dao;

import beans.Pessoa;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PessoaDAO {

    public void inserir(Pessoa pessoa) throws SQLException {
        if (pessoa.getNome() == null || pessoa.getNome().trim().isEmpty()) {
            throw new SQLException("Nome é obrigatório.");
        }

        String sql = "INSERT INTO pessoa(nome, sexo, idioma) VALUES (?,?,?)";

        Conexao conexao = new Conexao();

        try (Connection conn = conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, pessoa.getNome());
            stmt.setString(2, pessoa.getSexo());
            stmt.setString(3, pessoa.getIdioma());

            stmt.executeUpdate();
        }
    }
}
