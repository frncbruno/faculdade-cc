package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    public Connection getConexao() throws SQLException {
        Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/BDAula01?userTimeZone=true&serverTimeZone=UTC",
                "root", "laboratorio");
        System.out.println("Conexão efetuada!");
        return conn;
    }
}
