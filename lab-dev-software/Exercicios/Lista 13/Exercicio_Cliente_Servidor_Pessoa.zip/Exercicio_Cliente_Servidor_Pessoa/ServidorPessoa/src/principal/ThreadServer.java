package principal;

import beans.Pessoa;
import dao.PessoaDAO;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ThreadServer extends Thread {

    private Socket clienteSocket;

    public ThreadServer(Socket clienteSocket) {
        this.clienteSocket = clienteSocket;
    }

    @Override
    public void run() {
        ObjectOutputStream out = null;

        try {
            out = new ObjectOutputStream(clienteSocket.getOutputStream());
            out.flush();

            ObjectInputStream in = new ObjectInputStream(clienteSocket.getInputStream());

            Pessoa p = (Pessoa) in.readObject();
            System.out.println("Pessoa recebida: " + p.getNome());

            PessoaDAO pdao = new PessoaDAO();
            pdao.inserir(p);

            out.writeObject("Sucesso: pessoa cadastrada!");
            out.flush();

        } catch (Exception ex) {
            System.out.println("Erro ao cadastrar pessoa: " + ex.getMessage());

            try {
                if (out != null) {
                    out.writeObject("Erro: " + ex.getMessage());
                    out.flush();
                }
            } catch (IOException erro) {
                System.out.println("Não foi possível enviar a mensagem de erro.");
            }

        } finally {
            try {
                clienteSocket.close();
            } catch (IOException ex) {
                System.out.println("Erro ao fechar conexão: " + ex.getMessage());
            }
        }
    }
}
