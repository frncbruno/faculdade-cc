package principal;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class JavaDB {

    public static void main(String[] args) {
        int porta = 12345;

        try (ServerSocket servidorSocket = new ServerSocket(porta)) {
            System.out.println("Servidor aguardando conexões na porta " + porta);

            while (true) {
                try {
                    Socket clienteSocket = servidorSocket.accept();
                    System.out.println("Conexão aceita de " + clienteSocket.getInetAddress());

                    ThreadServer threadCliente = new ThreadServer(clienteSocket);
                    threadCliente.start();

                } catch (IOException ex) {
                    System.out.println("Erro ao aceitar conexão: " + ex.getMessage());
                }
            }

        } catch (IOException ex) {
            System.out.println("Erro ao criar o ServerSocket: " + ex.getMessage());
        }
    }
}
