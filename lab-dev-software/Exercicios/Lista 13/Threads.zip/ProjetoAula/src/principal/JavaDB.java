
package principal;

import beans.Pessoa;
import dao.PessoaDAO;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;

public class JavaDB { 
    public static void main(String[] args) {
        int porta = 12345; // Use uma constante para a porta

        try (ServerSocket servidorSocket = new ServerSocket(porta)) { 
            System.out.println("Servidor aguardando conexões na porta " + porta);
            
            while (true) {
                try { 
                    Socket clienteSocket = servidorSocket.accept();
                    System.out.println("Conexão aceita de " + clienteSocket.getInetAddress());

                    ObjectOutputStream out = new ObjectOutputStream(clienteSocket.getOutputStream());
                    ObjectInputStream in = new ObjectInputStream(clienteSocket.getInputStream());
                    
                    int id = in.readInt();
                    System.out.println("ID recebido: " + id);
                    
                    // Simule a obtenção de uma Pessoa a partir do ID
                    PessoaDAO pdao = new PessoaDAO();
                    Pessoa p = pdao.getPessoa(id);
                    
                    out.writeObject(p);
                    
                } catch (IOException ex) {
                    System.out.println("Erro ao aceitar conexão do cliente");
                }
            }
        } catch (IOException ex) {
            System.out.println("Erro ao criar o server socket");
        }
    }
}
