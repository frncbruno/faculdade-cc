package utilidades;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL; 

public class ValidadorUrl {
    /**
     * Valida se uma string representa uma URL válida e bem formada.
     * Aceita apenas os protocolos HTTP e HTTPS.
     *
     * @param urlString A URL em formato de texto a ser validada.
     * @return true se a URL for válida, false caso contrário.
     */
    public static boolean isLinkValido(String urlString) {
        if (urlString == null || urlString.trim().isEmpty()) {
            return false;
        }

        try {
            // 1. Converte para URI para validar a sintaxe estrita (RFC 2396)
            URI uri = new URI(urlString);

            // 2. Converte para URL para validar o protocolo e a estrutura de rede
            URL url = uri.toURL();

            // 3. Verifica se o protocolo é HTTP ou HTTPS
            String protocolo = url.getProtocol();
            if (!"http".equalsIgnoreCase(protocolo) && !"https".equalsIgnoreCase(protocolo)) {
                return false;
            }

            // 4. Garante que existe um domínio/host (evita URLs como "http://")
            String host = url.getHost();
            return host != null && !host.trim().isEmpty();

        } catch (URISyntaxException | MalformedURLException | IllegalArgumentException e) {
            return false;
        }
    }
}
