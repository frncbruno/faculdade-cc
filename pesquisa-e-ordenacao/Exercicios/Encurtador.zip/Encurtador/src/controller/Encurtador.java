/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.TabelaHash;

public class Encurtador {
    

    public static String encurtar(String linkOriginal, TabelaHash tabela){
        String DOMINIO = "localhost";
        
        String hashGerado = "" + (linkOriginal.hashCode() & 0x7fffffff);
        
        tabela.links.put(hashGerado, linkOriginal);
        
        return "https://" + DOMINIO + "/" + hashGerado; //Link encurtado
    }
    
    public static String buscarLinkEncurtado(String linkEncurtado, TabelaHash tabelaHash){
        String dadosLink[];
        dadosLink = linkEncurtado.split("/");
        String hashObtido = dadosLink [dadosLink.length - 1];
        
        
        return resposta = tabela.links.get(hashObtido);
        if (resposta.isEmpty()){
            resposta = "Link encurtado não encontrado!";
        }
        return resposta;
    }
}
