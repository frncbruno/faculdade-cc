
package utilidades;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import model.ProdutoModel;

public class GerenciadorArquivos {

    public static ArrayList<ProdutoModel> carregarArquivo(String nomeArquivo) {

        ArrayList<ProdutoModel> lista = new ArrayList<>();

        try {

            FileReader fr = new FileReader(nomeArquivo);
            BufferedReader bf = new BufferedReader(fr);

            String linha;

            // Ignora o cabecalho
            bf.readLine();

            while ((linha = bf.readLine()) != null) {

                String[] dados = linha.split(";");

                int id = Integer.parseInt(dados[0]);
                String nome = dados[1];
                String categoria = dados[2];
                double preco = Double.parseDouble(dados[3]);
                int estoque = Integer.parseInt(dados[4]);

                ProdutoModel p = new ProdutoModel(id, nome, categoria, preco, estoque);

                lista.add(p);
            }

            bf.close();

        } catch (Exception e) {
            System.out.println("Erro ao carregar arquivo: " + e.getMessage());
        }

        return lista;
    }

    public static void exportarArquivo(ArrayList<ProdutoModel> lista, String nomeArquivo) {

        try {

            FileWriter fw = new FileWriter(nomeArquivo);

            fw.write("id;nome;categoria;preco;estoque\n");

            for (int i = 0; i < lista.size(); i++) {

                ProdutoModel p = lista.get(i);

                fw.write(
                    p.getId() + ";" +
                    p.getNome() + ";" +
                    p.getCategoria() + ";" +
                    String.format(java.util.Locale.US, "%.2f", p.getPreco()) + ";" +
                    p.getEstoque() + "\n"
                );
            }

            fw.close();

        } catch (Exception e) {
            System.out.println("Erro ao exportar arquivo: " + e.getMessage());
        }
    }
}
