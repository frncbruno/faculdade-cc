package controller;

import java.util.ArrayList;
import java.util.Comparator;
import model.ProdutoModel;

public class Ordenador {

    // ORDENACAO BOLHA
    public static boolean bolha(ArrayList<ProdutoModel> lista,
            Comparator<ProdutoModel> comparador, long limiteNanos) {

        long inicio = System.nanoTime();
        boolean houveTroca;

        do {
            houveTroca = false;

            for (int i = 0; i < lista.size() - 1; i++) {

                if (comparador.compare(lista.get(i), lista.get(i + 1)) > 0) {

                    ProdutoModel aux = lista.get(i);
                    lista.set(i, lista.get(i + 1));
                    lista.set(i + 1, aux);

                    houveTroca = true;
                }

                if (System.nanoTime() - inicio >= limiteNanos) {
                    return false;
                }
            }

        } while (houveTroca);

        return true;
    }

    // ORDENACAO QUICK SORT
    public static void quickSort(ArrayList<ProdutoModel> lista,
            Comparator<ProdutoModel> comparador) {

        quickSort(lista, 0, lista.size() - 1, comparador);
    }

    private static void quickSort(ArrayList<ProdutoModel> lista,
            int inicio,
            int fim,
            Comparator<ProdutoModel> comparador) {

        if (inicio < fim) {

            int pivo = particionar(lista, inicio, fim, comparador);

            quickSort(lista, inicio, pivo - 1, comparador);

            quickSort(lista, pivo + 1, fim, comparador);
        }
    }

    private static int particionar(ArrayList<ProdutoModel> lista,
            int inicio,
            int fim,
            Comparator<ProdutoModel> comparador) {

        ProdutoModel pivo = lista.get(fim);

        int i = inicio - 1;

        for (int j = inicio; j < fim; j++) {

            if (comparador.compare(lista.get(j), pivo) <= 0) {

                i++;

                ProdutoModel aux = lista.get(i);

                lista.set(i, lista.get(j));
                lista.set(j, aux);
            }
        }

        ProdutoModel aux = lista.get(i + 1);

        lista.set(i + 1, lista.get(fim));
        lista.set(fim, aux);

        return i + 1;
    }
}
