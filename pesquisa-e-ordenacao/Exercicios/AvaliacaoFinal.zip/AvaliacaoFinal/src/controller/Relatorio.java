
package controller;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import model.ProdutoModel;
import utilidades.GerenciadorArquivos;

public class Relatorio {

    public static void gerarRelatorio() {

        String[] arquivos = {
            "produtos_1000.txt",
            "produtos_10000.txt",
            "produtos_50000.txt"
        };

        try {

            FileWriter fw = new FileWriter("relatorio.txt");

            fw.write("RELATORIO DE DESEMPENHO\n\n");

            for (int i = 0; i < arquivos.length; i++) {

                ArrayList<ProdutoModel> lista =
                        GerenciadorArquivos.carregarArquivo(arquivos[i]);

                fw.write("Arquivo: " + arquivos[i] + "\n");

                if (lista.isEmpty()) {
                    fw.write("Erro ao carregar arquivo.\n\n");
                    continue;
                }

                Comparator<ProdutoModel> porPreco =
                        (a, b) -> Double.compare(a.getPreco(), b.getPreco());

                // BUBBLE SORT

                ArrayList<ProdutoModel> bolha = new ArrayList<>(lista);

                long inicio = System.nanoTime();

                boolean terminou = Ordenador.bolha(
                        bolha, porPreco, 120_000_000_000L);

                long fim = System.nanoTime();

                if (terminou) {
                    fw.write("Bubble Sort: " + (fim - inicio) / 1000000.0 + " ms\n");
                } else {
                    fw.write("Bubble Sort: Nao concluido (> 2 min)\n");
                }

                // QUICK SORT

                ArrayList<ProdutoModel> quick = new ArrayList<>(lista);

                inicio = System.nanoTime();

                Ordenador.quickSort(quick, porPreco);

                fim = System.nanoTime();

                fw.write("Quick Sort: " + (fim - inicio) / 1000000.0 + " ms\n");

                // BUSCAS

                ArrayList<ProdutoModel> listaID = new ArrayList<>(lista);

                Comparator<ProdutoModel> porID =
                        (a, b) -> Integer.compare(a.getId(), b.getId());

                Ordenador.quickSort(listaID, porID);

                int id = lista.get(0).getId();

                inicio = System.nanoTime();

                for (int j = 0; j < 1000; j++) {
                    Buscador.buscaLinear(id, lista);
                }

                fim = System.nanoTime();

                fw.write("Busca Linear: " + (fim - inicio) / 1000.0 / 1000000.0 + " ms\n");

                inicio = System.nanoTime();

                for (int j = 0; j < 1000; j++) {
                    Buscador.buscaBinaria(id, listaID);
                }

                fim = System.nanoTime();

                fw.write("Busca Binaria: " + (fim - inicio) / 1000.0 / 1000000.0 + " ms\n");

                inicio = System.nanoTime();

                HashMap<Integer, ProdutoModel> mapa =
                        Buscador.criarIndiceId(lista);

                fim = System.nanoTime();

                fw.write("Criacao HashMap: " + (fim - inicio) / 1000000.0 + " ms\n");

                inicio = System.nanoTime();

                for (int j = 0; j < 1000; j++) {
                    Buscador.buscaHash(id, mapa);
                }

                fim = System.nanoTime();

                fw.write("Busca HashMap: " + (fim - inicio) / 1000.0 / 1000000.0 + " ms\n\n");
            }

            fw.write("RESUMO:\n");
            fw.write("HashMap costuma ser mais rapido em buscas repetidas.\n");
            fw.write("Busca binaria exige que a lista esteja ordenada por ID.\n");
            fw.write("HashMap compensa quando existem muitas consultas.\n");

            fw.close();

            System.out.println("Relatorio gerado!");

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
