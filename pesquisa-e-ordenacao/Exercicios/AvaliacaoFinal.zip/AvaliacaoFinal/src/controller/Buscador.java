
package controller;

import java.util.ArrayList;
import java.util.HashMap;
import model.ProdutoModel;

public class Buscador {

    // BUSCA LINEAR POR ID

    public static ProdutoModel buscaLinear(
            int id, ArrayList<ProdutoModel> lista) {

        for (int i = 0; i < lista.size(); i++) {

            if (lista.get(i).getId() == id) {
                return lista.get(i);
            }
        }

        return null;
    }

    // BUSCA BINARIA POR ID

    public static ProdutoModel buscaBinaria(
            int id, ArrayList<ProdutoModel> lista) {

        int inicio = 0;
        int fim = lista.size() - 1;

        while (inicio <= fim) {

            int meio = inicio + (fim - inicio) / 2;

            if (lista.get(meio).getId() == id) {
                return lista.get(meio);
            }

            if (id < lista.get(meio).getId()) {
                fim = meio - 1;
            } else {
                inicio = meio + 1;
            }
        }

        return null;
    }

    // CRIAR HASHMAP POR ID

    public static HashMap<Integer, ProdutoModel> criarIndiceId(
            ArrayList<ProdutoModel> lista) {

        HashMap<Integer, ProdutoModel> mapa = new HashMap<>();

        for (int i = 0; i < lista.size(); i++) {

            ProdutoModel p = lista.get(i);

            mapa.put(p.getId(), p);
        }

        return mapa;
    }

    // BUSCA POR ID NO HASHMAP

    public static ProdutoModel buscaHash(
            int id, HashMap<Integer, ProdutoModel> mapa) {

        return mapa.get(id);
    }

    // CRIAR HASHMAP POR CATEGORIA

    public static HashMap<String, ArrayList<ProdutoModel>> criarIndiceCategoria(
            ArrayList<ProdutoModel> lista) {

        HashMap<String, ArrayList<ProdutoModel>> mapa = new HashMap<>();

        for (int i = 0; i < lista.size(); i++) {

            ProdutoModel p = lista.get(i);

            String categoria = p.getCategoria().toLowerCase();

            if (!mapa.containsKey(categoria)) {

                mapa.put(categoria, new ArrayList<ProdutoModel>());
            }

            mapa.get(categoria).add(p);
        }

        return mapa;
    }

    // BUSCAR PRODUTOS POR CATEGORIA

    public static ArrayList<ProdutoModel> buscaCategoria(
            String categoria,
            HashMap<String, ArrayList<ProdutoModel>> mapa) {

        return mapa.get(categoria.toLowerCase());
    }
}
